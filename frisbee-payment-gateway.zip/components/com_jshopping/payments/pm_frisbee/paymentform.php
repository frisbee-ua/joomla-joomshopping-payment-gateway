<?php
/*
* @version      1.0.0
* @author       Frisbee
* @package      Jshopping
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/
defined('_JEXEC') or die('Restricted access');
?>
